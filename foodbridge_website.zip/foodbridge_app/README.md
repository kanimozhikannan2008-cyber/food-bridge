# FoodBridge demo app

A responsive front-end prototype built with **HTML, CSS and vanilla JavaScript**.

## Run it
1. Extract `foodbridge_app.zip`.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Choose a role on the login screen. For a quick demo, use any email/password. Create account stores a local demo profile.

## Included features
- Role choice at login: Food Donor, Food Recipient, Delivery Partner
- Signup form with organization, mobile number and address
- Emergency/support contact displayed on login (sample number, replace before deployment)
- Dashboard with visual impact cards, chart and recent activity
- Food donation board with search, type filters and sorting
- Donation and recipient-request forms
- Smart matching score using food compatibility, quantity, distance, urgency and fair access
- Basic double-reservation prevention in local demo state
- Delivery stages and manually updated delivery task history
- Recipient/donor/delivery actions in local history and CSV export
- Multilingual helper with simple built-in English, Tamil and Hindi responses
- Auto-rotate appearance option that follows the device's dark-mode preference, plus manual dark/light selection
- Responsive layout, CSS illustrations, emoji graphics, cards, toasts and modals

## Important prototype limits
This is a **front-end demo**, not a production-ready food logistics platform. Data is stored in the current browser's `localStorage`, so it is not shared across devices or users. Demo login is not secure authentication. The matching reservation logic is not safe for simultaneous real users without a backend transaction/locking mechanism. The chatbot is a small rule-based guide, not a live AI model. GPS, map routing, SMS/email notifications, verified identity, admin tools and real food-safety checks require backend services and external integrations. Replace the sample emergency contact with a real monitored contact before presenting it as operational.

For a production version, add a backend API and database, authentication and role-based authorization, atomic inventory reservations, audit logs, secure personal-data handling, and verified food-safety/transport workflows.
